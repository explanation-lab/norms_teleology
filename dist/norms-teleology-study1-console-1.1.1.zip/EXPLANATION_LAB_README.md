# Explanation Lab conversion report

Converted: 2026-10-31T16:03:07.296Z
Source ZIP: norms-teleology-study1-upload.zip
jsPsych: 7.3.4
Experiment version: norms-teleology-study1-1.1.1
Client version: 1.5.1
Assignment: between_participant
Launch assignment parameter: condition
Launch conditions: control, survival, ecology
Internal condition cells: none detected
Demographics: age, gender, other_gender, race, other_race, ethnicity
Package fingerprint: 51feccb88a5f2b1f2a7949fd838db07928fab69e31590674e87810c7f3b5226b

## Changes
- Added explanation-lab.config.json with confirmed versions and data mappings.
- Added a frozen local Explanation Lab client at explanation-lab-client.js.
- Preserved the existing Explanation Lab save integration and re-verified its launch assignment wiring.
- Verified that every condition reader in the package uses the Console assignment.

## Warnings from inspection
- None

## Required next steps
1. Open and test the converted study locally.
2. Publish this converted folder through GitHub Pages.
3. Register the public Pages URL in the Explanation Lab Console.
4. Paste the Pages URL into the Console; it will read and verify this manifest automatically.
5. Complete every Sandbox condition and inspect both CSV exports.
6. Do not launch while any readiness item remains incomplete.