NORMS TELEOLOGY — SINGLE-ANIMAL BETWEEN-SUBJECT PILOT
Version: norms-teleology-single-animal-pilot-1.0.0

Extract the whole ZIP and double-click index.html. Keep the folders together.
No installation, server, internet or sign-in is needed. JavaScript must be on.

Reviewer panel: select any of the three conditions and three animals (nine
combinations); jump to any screen, reveal the explanation box, shuffle question
order, restore canonical order, or download local responses.
Try participant flow opens participant.html without reviewer controls.

Each participant receives ONE condition: control, survival or ecological benefit.
Independently, ONE animal is sampled uniformly: Virdex, Nalk or Marvin.
This is random sampling, not animal quota balancing. Five questions are shuffled
once per participant. Condition, animal and question order persist on reload.
Each rating uses the same seven-point agreement scale. Selecting a rating
reveals a required written explanation. Continue requires both responses.
Story and matched images remain above each question. The revised value wording,
Marvin hoof spikes, concise instructions and optional demographics are retained.
Consent → instructions → one animal story → five rating/explanation pairs →
optional demographics → thank you. Nine recorded screens; five rating records.

JSON/CSV exports record condition, selected_animal_id, item_id, question order,
measure, rating and explanation. Demographics also have a separate CSV.
Review and local previews never submit participant data to a server.
Participant preview ignores URL condition/animal overrides and randomizes both.
Use Start another participant preview at the end to draw a new participant.

This is an offline reviewer and source preparation only. No new Console study
has been registered or deployed for this version. Existing live studies remain
unchanged. A future hosted version will use Console-assigned benefit conditions
and independently sample one animal in the browser. Recruitment targets for
this revised design have not been set.
