# Explanation Lab conversion report

Converted: 2026-11-01T16:02:20.132Z
Source ZIP: norms-teleology-single-animal-pilot-upload-1.0.0.zip
jsPsych: 7.3.4
Experiment version: norms-teleology-single-animal-pilot-1.0.0
Client version: 1.5.1
Assignment: between_participant
Launch assignment parameter: condition
Launch conditions: control, survival, ecology
Internal condition cells: none detected
Demographics: age, gender, other_gender, race, other_race, ethnicity
Package fingerprint: 3e7746bca36fae2fa24ba914328a015c98b7b445262d0eb7ddd1d5f80a0b9dc7

## Changes
- Added explanation-lab.config.json with confirmed versions and data mappings.
- Added a frozen local Explanation Lab client at explanation-lab-client.js.
- Preserved the existing Explanation Lab save integration and re-verified its launch assignment wiring.
- Connected 1 assignment reader to the Console assignment.
- Verified that every condition reader in the package uses the Console assignment.

## Warnings from inspection
- None

## Required next steps
1. Open and test the converted study locally.
2. Publish this converted folder through GitHub Pages.
3. Register the public Pages URL in the Explanation Lab Console.
4. Paste the Pages URL into the Console; it will read and verify this manifest automatically.
5. Complete every Sandbox condition and inspect both CSV exports.
6. Do not launch while any readiness item remains incomplete.