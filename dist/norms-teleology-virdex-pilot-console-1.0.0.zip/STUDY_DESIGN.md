# Virdex pilot with four new measures

DESIGN
Between participants: one condition per person. Everyone sees only Virdexes.
The revised November 2 Virdex cases and the same spotted/unspotted image pair are
retained. In the survival case the scent helps the individual Virdex survive;
in ecology it helps nearby tree frogs survive; the control scent has no significant
effects on the Virdex or the other animals in the area.

The four statements are:
1. Virdexes ought to have spots
2. It would be best for a Virdex to have spots
3. If a Virdex doesn’t have spots, there’s probably something wrong with it.
4. The spots make Virdexes especially important creatures.

These replace all five previous measures. The four questions are randomized once
per participant; the reviewer initially uses the order above and can shuffle it.
Each question uses the same fully labeled seven-point agreement scale and a
required explanation box, revealed after choosing a rating. Both responses are
required before Continue. The story and images remain visible above the question.

Consent, concise instructions and optional demographics match the previous study.
Consent → instructions → Virdex story → four rating/explanation pairs → optional
demographics → thank you. Eight recorded screens, including four response records.
Condition and question order persist on reload. Local participant previews sample
one of the three conditions uniformly. A future Console release can assign the
condition through a balanced study link. Recruitment targets are not yet set.

EXPORTS
JSON and ratings CSV include condition, item_id=virdex, question_id, measure,
question order, statement, rating and explanation. Measures are ought_to_have,
best_to_have, wrongness and special_importance. Review/local responses stay in
this browser and are never submitted to the Console or Prolific.

STATUS
Offline reviewer only. This new pilot has not been registered or deployed to the
Study Console. Existing study versions, targets and participant data are unchanged.
