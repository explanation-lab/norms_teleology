# Explanation Lab conversion report

Converted: 2026-11-03T14:32:18.835Z
Source ZIP: norms-teleology-virdex-pilot-upload-1.0.0.zip
jsPsych: 7.3.4
Experiment version: norms-teleology-virdex-pilot-1.0.0
Client version: 1.5.1
Assignment: between_participant
Launch assignment parameter: condition
Launch conditions: control, survival, ecology
Internal condition cells: none detected
Demographics: age, gender, other_gender, race, other_race, ethnicity
Package fingerprint: e3578ab84c4b4cb8ff9f3c5b1b203da653c4e2fad84b6b35efa2ee893b515337

## Changes
- Added explanation-lab.config.json with confirmed versions and data mappings.
- Added a frozen local Explanation Lab client at explanation-lab-client.js.
- Preserved the existing Explanation Lab save integration and re-verified its launch assignment wiring.
- Connected 1 assignment reader to the Console assignment.
- Verified that every condition reader in the package uses the Console assignment.

## Warnings from inspection
- None

## Required next steps
1. Open and test the converted study locally.
2. Publish this converted folder through GitHub Pages.
3. Register the public Pages URL in the Explanation Lab Console.
4. Paste the Pages URL into the Console; it will read and verify this manifest automatically.
5. Complete every Sandbox condition and inspect both CSV exports.
6. Do not launch while any readiness item remains incomplete.