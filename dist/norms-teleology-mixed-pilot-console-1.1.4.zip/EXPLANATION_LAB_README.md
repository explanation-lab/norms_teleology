# Explanation Lab conversion report

Converted: 2026-11-01T13:32:41.963Z
Source ZIP: norms-teleology-mixed-pilot-upload-1.1.4.zip
jsPsych: 7.3.4
Experiment version: norms-teleology-mixed-pilot-1.1.4
Client version: 1.5.1
Assignment: counterbalanced_within_participant
Launch assignment parameter: order
Launch conditions: p1, p2, p3, p4, p5, p6
Internal condition cells: control, ecology, p1, p2, p3, p4, p5, p6, string, survival
Demographics: age, gender, other_gender, race, other_race, ethnicity
Package fingerprint: dd469a474218d5656d4f40b71531551d0d2ca6b941e645d56c5e2e9519d8f5e0

## Changes
- Added explanation-lab.config.json with confirmed versions and data mappings.
- Added a frozen local Explanation Lab client at explanation-lab-client.js.
- Preserved the existing Explanation Lab save integration and re-verified its launch assignment wiring.
- Verified that every order reader in the package uses the Console assignment.

## Warnings from inspection
- A within-participant design was detected. The Console will use one launch group named mixed; internal trial cells remain inside jsPsych.

## Required next steps
1. Open and test the converted study locally.
2. Publish this converted folder through GitHub Pages.
3. Register the public Pages URL in the Explanation Lab Console.
4. Paste the Pages URL into the Console; it will read and verify this manifest automatically.
5. Complete every Sandbox condition and inspect both CSV exports.
6. Do not launch while any readiness item remains incomplete.